{{-- Footer Section --}}
<script type="text/javascript" src="{!! asset('script/jquery.js') !!}"></script>

</body>
</html>