{{-- Footer Section --}}
<script type="text/javascript" src="{!! asset('script/jquery.js') !!}"></script>
<script type="text/javascript" src="{!! asset('script/angular.js') !!}"></script>
<script type="text/javascript" src="{!! asset('script/loading-bar.js') !!}"></script>
<script type="text/javascript" src="{!! asset('script/dropzone.js') !!}"></script>
<script type="text/javascript" src="{!! asset('script/app.js') !!}"></script>

</body>
</html>