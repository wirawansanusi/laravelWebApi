<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MLMFoto Products List</title>
<link href="{!! asset('css/app.css') !!}" media="all" rel="stylesheet" type="text/css" />
<link href="{!! asset('css/all.css') !!}" media="all" rel="stylesheet" type="text/css" />
<body>