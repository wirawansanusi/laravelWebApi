<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostThumbnail extends Model
{
    //
}
